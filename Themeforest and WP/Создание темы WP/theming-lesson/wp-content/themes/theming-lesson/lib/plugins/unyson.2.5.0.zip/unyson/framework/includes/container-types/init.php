<?php if (!defined('FW')) die('Forbidden');

$dir = dirname(__FILE__);

require $dir . '/simple.php';

require $dir .'/tab/class-fw-container-type-tab.php';
require $dir .'/box/class-fw-container-type-box.php';
require $dir .'/popup/class-fw-container-type-popup.php';